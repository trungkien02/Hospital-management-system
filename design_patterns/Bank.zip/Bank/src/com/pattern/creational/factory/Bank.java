package com.pattern.creational.factory;

public interface Bank {
    String getBankName();
}
