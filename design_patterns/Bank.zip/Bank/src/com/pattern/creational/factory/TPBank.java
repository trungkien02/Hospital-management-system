package com.pattern.creational.factory;

public class TPBank implements Bank {

    @Override
    public String getBankName() {
        return "TPBank";
    }

}
