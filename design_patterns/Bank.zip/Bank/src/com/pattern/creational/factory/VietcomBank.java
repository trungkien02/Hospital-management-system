package com.pattern.creational.factory;

public class VietcomBank implements Bank {

    @Override
    public String getBankName() {
        return "VietcomBank";
    }

}
