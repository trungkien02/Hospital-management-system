package com.pattern.creational.factory;

public enum BankType {

    VIETCOMBANK, TPBANK;

}
